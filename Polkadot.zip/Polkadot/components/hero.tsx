import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-32 lg:py-40">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="animate-fade-in-up">
            <div className="inline-block mb-4 px-4 py-2 bg-primary/10 rounded-full border border-primary/20">
              <span className="text-sm font-semibold text-primary">Powered by Polkadot Blockchain</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Fair Prices for African Farmers
            </h1>

            <p className="text-lg text-foreground/70 mb-8 leading-relaxed">
              AgriChain connects African farmers directly to global markets using Polkadot blockchain. Transparent
              supply chains, instant payments, and fair prices—no middlemen.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Link href="/signup">Start Farming Smart</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="#how-it-works">Learn More</Link>
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-border">
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-primary">50K+</div>
                <p className="text-sm text-foreground/60">Farmers Connected</p>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-accent">$2.5M</div>
                <p className="text-sm text-foreground/60">Paid to Farmers</p>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-primary">15+</div>
                <p className="text-sm text-foreground/60">Countries</p>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative animate-slide-in-right">
            <div className="relative h-96 sm:h-[500px] bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl border border-primary/20 overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-4xl">🌾</span>
                  </div>
                  <p className="text-foreground/60 font-semibold">Blockchain-Powered Agriculture</p>
                </div>
              </div>

              {/* Decorative elements */}
              <div className="absolute top-10 right-10 w-20 h-20 bg-accent/30 rounded-full blur-2xl" />
              <div className="absolute bottom-10 left-10 w-32 h-32 bg-primary/20 rounded-full blur-3xl" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
