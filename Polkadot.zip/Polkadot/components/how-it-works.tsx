import { Card } from "@/components/ui/card"

const steps = [
  {
    number: "01",
    title: "Create Your Account",
    description: "Sign up with your email and create a secure Polkadot wallet. Verify your farm details.",
  },
  {
    number: "02",
    title: "List Your Products",
    description: "Add your crops with details, quantity, and pricing. Include photos and sustainability info.",
  },
  {
    number: "03",
    title: "Connect with Buyers",
    description: "Buyers from around the world can see your products. Negotiate directly or accept offers.",
  },
  {
    number: "04",
    title: "Get Paid Instantly",
    description: "Once order is confirmed, payment goes directly to your wallet in stablecoins.",
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4">How AgriChain Works</h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Simple steps to start selling your crops globally
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="p-6 h-full border-border/50">
                <div className="text-4xl font-bold text-primary/20 mb-4">{step.number}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-foreground/60">{step.description}</p>
              </Card>

              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-primary to-transparent" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
