"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { getAccountBalance } from "@/lib/polkadot/client";

interface PolkadotAccountProps {
  address: string;
}

export default function PolkadotAccount({ address }: PolkadotAccountProps) {
  const [balance, setBalance] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchBalance = async () => {
      try {
        setLoading(true);
        const bal = await getAccountBalance(address);
        setBalance(bal);
        setError("");
      } catch (err: any) {
        setError(err.message);
        setBalance("");
      } finally {
        setLoading(false);
      }
    };

    fetchBalance();
  }, [address]);

  return (
    <Card className="p-4 bg-background/50 border-primary/20">
      <p className="text-xs text-muted-foreground mb-2">Polkadot Balance</p>
      {loading ? (
        <p className="text-lg font-semibold">Loading...</p>
      ) : error ? (
        <p className="text-sm text-red-600">{error}</p>
      ) : (
        <p className="text-2xl font-bold text-foreground">{balance} DOT</p>
      )}
    </Card>
  );
}
