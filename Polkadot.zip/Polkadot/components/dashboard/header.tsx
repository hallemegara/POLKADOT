"use client"

import { Button } from "@/components/ui/button"
import { Menu, Bell, Settings, LogOut } from "lucide-react"

interface DashboardHeaderProps {
  onMenuClick: () => void
}

export function DashboardHeader({ onMenuClick }: DashboardHeaderProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
      <button onClick={onMenuClick} className="lg:hidden p-2 hover:bg-muted rounded-lg transition">
        <Menu size={24} />
      </button>

      <div className="flex-1" />

      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-muted rounded-lg transition relative">
          <Bell size={20} className="text-foreground/70" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full" />
        </button>

        <button className="p-2 hover:bg-muted rounded-lg transition">
          <Settings size={20} className="text-foreground/70" />
        </button>

        <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-primary-foreground font-bold">
          AF
        </div>

        <Button variant="ghost" size="sm" className="text-foreground/70 hover:text-foreground">
          <LogOut size={18} />
        </Button>
      </div>
    </header>
  )
}
