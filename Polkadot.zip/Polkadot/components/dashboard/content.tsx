"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, Users, ShoppingCart, Leaf, ArrowUpRight, ArrowDownLeft } from "lucide-react"
import Link from "next/link"

export function DashboardContent() {
  return (
    <main className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Welcome back, Amara!</h1>
          <p className="text-foreground/60">Here's your farm performance this month</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="p-6 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-primary" />
              </div>
              <span className="text-xs font-semibold text-accent flex items-center gap-1">
                <ArrowUpRight size={14} /> 12%
              </span>
            </div>
            <p className="text-foreground/60 text-sm mb-1">Total Sales</p>
            <p className="text-2xl font-bold text-foreground">$8,240</p>
          </Card>

          <Card className="p-6 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-accent" />
              </div>
              <span className="text-xs font-semibold text-accent flex items-center gap-1">
                <ArrowUpRight size={14} /> 8%
              </span>
            </div>
            <p className="text-foreground/60 text-sm mb-1">Active Buyers</p>
            <p className="text-2xl font-bold text-foreground">24</p>
          </Card>

          <Card className="p-6 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <span className="text-xs font-semibold text-accent flex items-center gap-1">
                <ArrowUpRight size={14} /> 5%
              </span>
            </div>
            <p className="text-foreground/60 text-sm mb-1">Avg Price/Unit</p>
            <p className="text-2xl font-bold text-foreground">$12.50</p>
          </Card>

          <Card className="p-6 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <Leaf className="w-6 h-6 text-accent" />
              </div>
              <span className="text-xs font-semibold text-primary flex items-center gap-1">
                <ArrowDownLeft size={14} /> 2%
              </span>
            </div>
            <p className="text-foreground/60 text-sm mb-1">Sustainability Score</p>
            <p className="text-2xl font-bold text-foreground">92%</p>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-6 border-border/50">
            <h2 className="text-lg font-bold text-foreground mb-4">Recent Orders</h2>
            <div className="space-y-4">
              {[
                { buyer: "Global Foods Ltd", amount: "$1,200", product: "Cocoa Beans", status: "Completed" },
                { buyer: "African Exports", amount: "$850", product: "Coffee", status: "In Transit" },
                { buyer: "Fair Trade Co", amount: "$650", product: "Vegetables", status: "Pending" },
              ].map((order, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div>
                    <p className="font-medium text-foreground">{order.buyer}</p>
                    <p className="text-sm text-foreground/60">{order.product}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">{order.amount}</p>
                    <p
                      className={`text-xs font-semibold ${
                        order.status === "Completed"
                          ? "text-primary"
                          : order.status === "In Transit"
                            ? "text-accent"
                            : "text-foreground/60"
                      }`}
                    >
                      {order.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 border-border/50">
            <h2 className="text-lg font-bold text-foreground mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                List New Product
              </Button>
              <Link href="/dashboard/wallet" className="block">
                <Button variant="outline" className="w-full bg-transparent">
                  View Wallet
                </Button>
              </Link>
              <Button variant="outline" className="w-full bg-transparent">
                Track Shipment
              </Button>
              <Link href="/dashboard/payments" className="block">
                <Button variant="outline" className="w-full bg-transparent">
                  View Payments
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </main>
  )
}
