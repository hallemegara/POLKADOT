"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { useState } from "react"

export function MarketplaceHeader() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">AC</span>
          </div>
          <span className="font-bold text-xl text-foreground hidden sm:inline">AgriChain</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link href="/marketplace" className="text-foreground font-medium">
            Marketplace
          </Link>
          <Link href="/dashboard" className="text-foreground/70 hover:text-foreground transition">
            Dashboard
          </Link>
          <Link href="#" className="text-foreground/70 hover:text-foreground transition">
            About
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Button variant="outline" asChild>
            <Link href="/dashboard">My Account</Link>
          </Button>
          <Button asChild className="bg-primary hover:bg-primary/90">
            <Link href="/dashboard/products">Sell Products</Link>
          </Button>
        </div>

        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 hover:bg-muted rounded-lg transition">
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {isOpen && (
        <div className="md:hidden border-t border-border bg-card">
          <div className="px-4 py-4 space-y-3">
            <Link href="/marketplace" className="block text-foreground py-2">
              Marketplace
            </Link>
            <Link href="/dashboard" className="block text-foreground/70 py-2">
              Dashboard
            </Link>
            <Link href="#" className="block text-foreground/70 py-2">
              About
            </Link>
            <div className="pt-3 space-y-2 border-t border-border">
              <Button variant="outline" asChild className="w-full bg-transparent">
                <Link href="/dashboard">My Account</Link>
              </Button>
              <Button asChild className="w-full bg-primary hover:bg-primary/90">
                <Link href="/dashboard/products">Sell Products</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
