"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface MarketplaceFiltersProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

export function MarketplaceFilters({ selectedCategory, onCategoryChange }: MarketplaceFiltersProps) {
  const categories = [
    { id: "all", label: "All Products" },
    { id: "cocoa", label: "Cocoa" },
    { id: "coffee", label: "Coffee" },
    { id: "vegetables", label: "Vegetables" },
    { id: "nuts", label: "Nuts" },
    { id: "other", label: "Other" },
  ]

  return (
    <Card className="p-4 border-border/50 mb-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
        {categories.map((category) => (
          <Button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            variant={selectedCategory === category.id ? "default" : "outline"}
            className={`text-sm ${
              selectedCategory === category.id
                ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                : "bg-transparent border-border hover:bg-muted"
            }`}
          >
            {category.label}
          </Button>
        ))}
      </div>
    </Card>
  )
}
