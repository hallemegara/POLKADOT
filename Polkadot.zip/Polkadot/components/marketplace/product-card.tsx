"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, MapPin, CheckCircle, Leaf } from "lucide-react"
import { useState } from "react"

interface Product {
  id: number
  name: string
  farmer: string
  location: string
  price: number
  quantity: string
  rating: number
  reviews: number
  image: string
  verified: boolean
  sustainability: number
}

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const [isAdded, setIsAdded] = useState(false)

  return (
    <Card className="overflow-hidden border-border/50 hover:shadow-lg transition-shadow group">
      {/* Image */}
      <div className="relative h-48 bg-muted overflow-hidden">
        <img
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {product.verified && (
          <div className="absolute top-3 right-3 bg-primary/90 backdrop-blur-sm rounded-full p-2">
            <CheckCircle className="w-4 h-4 text-primary-foreground" />
          </div>
        )}
        <div className="absolute top-3 left-3 bg-accent/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
          <Leaf className="w-3 h-3 text-accent-foreground" />
          <span className="text-xs font-semibold text-accent-foreground">{product.sustainability}%</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-bold text-foreground mb-1 line-clamp-2">{product.name}</h3>

        {/* Farmer Info */}
        <div className="mb-3">
          <p className="text-sm font-medium text-foreground">{product.farmer}</p>
          <div className="flex items-center gap-1 text-xs text-foreground/60">
            <MapPin size={14} />
            {product.location}
          </div>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                size={14}
                className={i < Math.floor(product.rating) ? "fill-accent text-accent" : "text-border"}
              />
            ))}
          </div>
          <span className="text-xs text-foreground/60">
            {product.rating} ({product.reviews})
          </span>
        </div>

        {/* Price & Quantity */}
        <div className="mb-4 pb-4 border-t border-border">
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-2xl font-bold text-primary">${product.price}</span>
            <span className="text-sm text-foreground/60">/kg</span>
          </div>
          <p className="text-xs text-foreground/60 mt-1">Available: {product.quantity}</p>
        </div>

        {/* CTA */}
        <Button
          onClick={() => setIsAdded(!isAdded)}
          className={`w-full transition-all ${
            isAdded
              ? "bg-primary/20 text-primary hover:bg-primary/30"
              : "bg-primary hover:bg-primary/90 text-primary-foreground"
          }`}
        >
          {isAdded ? "Added to Cart" : "Add to Cart"}
        </Button>
      </div>
    </Card>
  )
}
