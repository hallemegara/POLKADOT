import { Card } from "@/components/ui/card"
import { MapPin } from "lucide-react"

export function SupplyChainMap() {
  return (
    <Card className="p-6 border-border/50">
      <h2 className="text-lg font-bold text-foreground mb-4">Route Map</h2>
      <div className="relative h-64 bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg border border-primary/20 flex items-center justify-center overflow-hidden">
        {/* Simplified map visualization */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full mx-auto mb-3 flex items-center justify-center">
              <MapPin className="w-8 h-8 text-primary-foreground" />
            </div>
            <p className="text-sm font-semibold text-foreground">Lagos → Accra → Nairobi</p>
            <p className="text-xs text-foreground/60 mt-1">3,200 km total distance</p>
          </div>
        </div>

        {/* Decorative route line */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 300">
          <path
            d="M 50 150 Q 200 50 350 150"
            stroke="currentColor"
            strokeWidth="2"
            fill="none"
            className="text-primary/30"
            strokeDasharray="5,5"
          />
          <circle cx="50" cy="150" r="6" fill="currentColor" className="text-primary" />
          <circle cx="350" cy="150" r="6" fill="currentColor" className="text-accent" />
        </svg>
      </div>

      {/* Route Details */}
      <div className="mt-4 space-y-2">
        <div className="flex items-center gap-2 text-sm">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-foreground/70">Origin: Lagos, Nigeria</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-3 h-3 rounded-full bg-accent" />
          <span className="text-foreground/70">Destination: Nairobi, Kenya</span>
        </div>
      </div>
    </Card>
  )
}
