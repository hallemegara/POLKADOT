import { Card } from "@/components/ui/card"
import { Truck, Package, Clock, TrendingUp } from "lucide-react"

export function SupplyChainStats() {
  const stats = [
    { icon: Truck, label: "Active Shipments", value: "3", color: "text-primary" },
    { icon: Package, label: "Completed", value: "24", color: "text-accent" },
    { icon: Clock, label: "Avg Delivery", value: "3.2 days", color: "text-primary" },
    { icon: TrendingUp, label: "On-Time Rate", value: "98%", color: "text-accent" },
  ]

  return (
    <div className="space-y-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon
        return (
          <Card key={index} className="p-4 border-border/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className="flex-1">
                <p className="text-xs text-foreground/60">{stat.label}</p>
                <p className="text-lg font-bold text-foreground">{stat.value}</p>
              </div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
