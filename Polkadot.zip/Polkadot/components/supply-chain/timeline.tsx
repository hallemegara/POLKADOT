import { Card } from "@/components/ui/card"
import { CheckCircle, Clock, AlertCircle } from "lucide-react"

export function SupplyChainTimeline() {
  const events = [
    { time: "2025-01-15 08:00", event: "Order Confirmed", status: "completed" },
    { time: "2025-01-15 10:30", event: "Packaging Started", status: "completed" },
    { time: "2025-01-15 14:00", event: "Quality Check Passed", status: "completed" },
    { time: "2025-01-16 06:00", event: "Shipped from Farm", status: "completed" },
    { time: "2025-01-17 12:00", event: "In Transit", status: "active" },
    { time: "2025-01-19 10:00", event: "Expected Delivery", status: "pending" },
  ]

  return (
    <Card className="p-6 border-border/50">
      <h2 className="text-lg font-bold text-foreground mb-4">Shipment Timeline</h2>
      <div className="space-y-4">
        {events.map((item, index) => {
          const Icon = item.status === "completed" ? CheckCircle : item.status === "active" ? Clock : AlertCircle
          const color =
            item.status === "completed"
              ? "text-primary"
              : item.status === "active"
                ? "text-accent"
                : "text-foreground/40"

          return (
            <div key={index} className="flex gap-4">
              <div className="flex flex-col items-center">
                <Icon className={`w-5 h-5 ${color}`} />
                {index < events.length - 1 && (
                  <div className={`w-0.5 h-12 mt-2 ${item.status === "completed" ? "bg-primary" : "bg-border"}`} />
                )}
              </div>
              <div className="pb-4">
                <p className="text-sm font-semibold text-foreground">{item.event}</p>
                <p className="text-xs text-foreground/60">{item.time}</p>
              </div>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
