"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getChainInfo, getAccountBalance } from "@/lib/polkadot/client";
import type { PolkadotChainInfo, PolkadotError } from "@/lib/polkadot/types";

export default function PolkadotConnection() {
  const [chainInfo, setChainInfo] = useState<PolkadotChainInfo | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchChainInfo = async () => {
      try {
        setLoading(true);
        const info = await getChainInfo();
        setChainInfo(info);
        setIsConnected(true);
        setError("");
      } catch (err) {
        const polkadotError = err as PolkadotError;
        setError(polkadotError.message);
        setIsConnected(false);
        setChainInfo(null);
      } finally {
        setLoading(false);
      }
    };

    fetchChainInfo();

    // Poll for updates every 12 seconds (approximately one block time on Polkadot)
    const interval = setInterval(fetchChainInfo, 12000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20 mb-8">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-1">Blockchain Status</p>
          {loading ? (
            <p className="text-lg font-semibold text-foreground">Connecting to Polkadot...</p>
          ) : isConnected && chainInfo ? (
            <>
              <p className="text-lg font-semibold text-green-600">✓ Connected to {chainInfo.chainName}</p>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <p className="text-xs text-muted-foreground">Latest Block</p>
                  <code className="bg-background/50 px-2 py-1 rounded text-sm font-mono text-foreground">
                    {chainInfo.blockNumber}
                  </code>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Version</p>
                  <p className="text-sm font-mono text-foreground">{chainInfo.chainVersion}</p>
                </div>
              </div>
            </>
          ) : (
            <p className="text-lg font-semibold text-red-600">✗ Connection Failed</p>
          )}
          {error && (
            <p className="text-xs text-red-600 mt-2">{error}</p>
          )}
        </div>
        <Badge className={isConnected ? "bg-green-500/20 text-green-700 border-green-500/30" : "bg-red-500/20 text-red-700 border-red-500/30"}>
          {isConnected ? "Live" : "Offline"}
        </Badge>
      </div>
    </Card>
  );
}
