import { useEffect } from 'react';
import { ApiPromise, WsProvider } from '@polkadot/api';

export default function PolkadotTest() {
  useEffect(() => {
    async function connect() {
      const provider = new WsProvider('wss://rpc.polkadot.io');
      const api = await ApiPromise.create({ provider });
      const chain = await api.rpc.system.chain();
      console.log(`Connected to ${chain}`);
    }
    connect();
  }, []);

  return <div>Check the console for Polkadot chain info.</div>;
}
