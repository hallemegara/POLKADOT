import { createUser } from "@/lib/auth"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, fullName, farmName, location, cropType } = body

    // Validation
    if (!email || !password || !fullName || !farmName || !location || !cropType) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 })
    }

    // Create user
    const user = createUser(email, password, fullName, farmName, location, cropType)

    const response = NextResponse.json({ message: "Account created successfully", user }, { status: 201 })

    // Set a simple session token (in production, use proper JWT)
    response.cookies.set("agrichain_session", user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })

    return response
  } catch (error) {
    const message = error instanceof Error ? error.message : "Signup failed"
    return NextResponse.json({ error: message }, { status: 400 })
  }
}
