import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Mail, ArrowRight } from 'lucide-react'

export default function VerifyEmailPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold">AC</span>
            </div>
            <span className="font-bold text-xl text-foreground">AgriChain</span>
          </Link>
        </div>

        <Card className="p-8 border-border/50 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Mail className="w-8 h-8 text-primary" />
            </div>
          </div>
          
          <h1 className="text-2xl font-bold text-foreground mb-3">Verify Your Email</h1>
          <p className="text-foreground/70 mb-6">
            We've sent a verification link to your email address. Please check your inbox and click the link to verify your account.
          </p>

          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-6">
            <p className="text-sm text-foreground/80">
              Once verified, you'll be able to access your AgriChain dashboard and start connecting with buyers.
            </p>
          </div>

          <Link href="/login" className="inline-block">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Back to Login <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>

          <p className="text-center text-sm text-foreground/60 mt-6">
            Didn't receive the email?{" "}
            <button className="text-primary hover:underline font-medium">
              Resend
            </button>
          </p>
        </Card>
      </div>
    </div>
  )
}
