"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MarketplaceHeader } from "@/components/marketplace/header"
import { ProductCard } from "@/components/marketplace/product-card"
import { MarketplaceFilters } from "@/components/marketplace/filters"
import { Search, Filter } from "lucide-react"

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [showFilters, setShowFilters] = useState(false)

  const products = [
    {
      id: 1,
      name: "Premium Cocoa Beans",
      farmer: "Amara Okonkwo",
      location: "Lagos, Nigeria",
      price: 12.5,
      quantity: "500 kg",
      rating: 4.8,
      reviews: 124,
      image: "/cocoa-beans.jpg",
      category: "cocoa",
      verified: true,
      sustainability: 95,
    },
    {
      id: 2,
      name: "Organic Coffee Beans",
      farmer: "Kwame Mensah",
      location: "Accra, Ghana",
      price: 18.75,
      quantity: "200 kg",
      rating: 4.9,
      reviews: 89,
      image: "/pile-of-coffee-beans.png",
      category: "coffee",
      verified: true,
      sustainability: 98,
    },
    {
      id: 3,
      name: "Fresh Vegetables Mix",
      farmer: "Zainab Hassan",
      location: "Nairobi, Kenya",
      price: 8.2,
      quantity: "1000 kg",
      rating: 4.7,
      reviews: 156,
      image: "/fresh-vegetables.png",
      category: "vegetables",
      verified: true,
      sustainability: 92,
    },
    {
      id: 4,
      name: "Shea Butter",
      farmer: "Fatima Diallo",
      location: "Bamako, Mali",
      price: 22.0,
      quantity: "100 kg",
      rating: 4.9,
      reviews: 67,
      image: "/shea-butter.jpg",
      category: "other",
      verified: true,
      sustainability: 96,
    },
    {
      id: 5,
      name: "Cashew Nuts",
      farmer: "John Osei",
      location: "Kumasi, Ghana",
      price: 15.5,
      quantity: "300 kg",
      rating: 4.6,
      reviews: 98,
      image: "/cashew-nuts.jpg",
      category: "nuts",
      verified: true,
      sustainability: 88,
    },
    {
      id: 6,
      name: "Honey",
      farmer: "Amina Mohamed",
      location: "Addis Ababa, Ethiopia",
      price: 25.0,
      quantity: "50 kg",
      rating: 4.8,
      reviews: 112,
      image: "/golden-honey.png",
      category: "other",
      verified: true,
      sustainability: 99,
    },
  ]

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.farmer.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-background">
      <MarketplaceHeader />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search & Filters */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-foreground/40" />
              <Input
                type="text"
                placeholder="Search products or farmers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 bg-transparent"
            >
              <Filter size={18} />
              Filters
            </Button>
          </div>

          {/* Filters */}
          {showFilters && (
            <MarketplaceFilters selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
          )}
        </div>

        {/* Results Info */}
        <div className="mb-6">
          <p className="text-foreground/60">
            Showing <span className="font-semibold text-foreground">{filteredProducts.length}</span> products
          </p>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center border-border/50">
            <p className="text-foreground/60 mb-4">No products found matching your search.</p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("all")
              }}
              className="bg-transparent"
            >
              Clear Filters
            </Button>
          </Card>
        )}
      </main>
    </div>
  )
}
