import { redirect } from 'next/navigation'
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardContent } from "@/components/dashboard/content"

export default async function DashboardPage() {
  const supabase = await createClient()
  
  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/login")
  }

  return (
    <div className="flex h-screen bg-background">
      <DashboardSidebar open={true} onToggle={() => {}} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader onMenuClick={() => {}} />
        <DashboardContent />
      </div>
    </div>
  )
}
