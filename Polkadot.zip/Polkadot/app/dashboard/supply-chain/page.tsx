"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SupplyChainTimeline } from "@/components/supply-chain/timeline"
import { SupplyChainMap } from "@/components/supply-chain/map"
import { SupplyChainStats } from "@/components/supply-chain/stats"
import { Package, MapPin, CheckCircle } from "lucide-react"

export default function SupplyChainPage() {
  return (
    <main className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Supply Chain Tracking</h1>
            <p className="text-foreground/60">Monitor your products from farm to buyer</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">+ New Shipment</Button>
        </div>

        {/* Active Shipments */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-6 border-border/50">
            <h2 className="text-lg font-bold text-foreground mb-4">Active Shipments</h2>
            <div className="space-y-4">
              {[
                {
                  id: "SHP-001",
                  product: "Cocoa Beans",
                  quantity: "500 kg",
                  buyer: "Global Foods Ltd",
                  status: "In Transit",
                  progress: 65,
                  location: "Lagos, Nigeria",
                  eta: "2 days",
                },
                {
                  id: "SHP-002",
                  product: "Coffee",
                  quantity: "200 kg",
                  buyer: "African Exports",
                  status: "Processing",
                  progress: 40,
                  location: "Addis Ababa, Ethiopia",
                  eta: "4 days",
                },
                {
                  id: "SHP-003",
                  product: "Vegetables",
                  quantity: "1000 kg",
                  buyer: "Fair Trade Co",
                  status: "Pending",
                  progress: 10,
                  location: "Nairobi, Kenya",
                  eta: "6 days",
                },
              ].map((shipment) => (
                <div key={shipment.id} className="border border-border/50 rounded-lg p-4 hover:bg-muted/30 transition">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Package size={18} className="text-primary" />
                        <p className="font-bold text-foreground">{shipment.product}</p>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">{shipment.id}</span>
                      </div>
                      <p className="text-sm text-foreground/60">
                        {shipment.quantity} to {shipment.buyer}
                      </p>
                    </div>
                    <span
                      className={`text-xs font-semibold px-3 py-1 rounded-full ${
                        shipment.status === "In Transit"
                          ? "bg-accent/20 text-accent"
                          : shipment.status === "Processing"
                            ? "bg-primary/20 text-primary"
                            : "bg-muted text-foreground/60"
                      }`}
                    >
                      {shipment.status}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-foreground/60">Progress</span>
                      <span className="text-xs font-semibold text-foreground">{shipment.progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                        style={{ width: `${shipment.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Location & ETA */}
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-foreground/60">
                      <MapPin size={16} />
                      {shipment.location}
                    </div>
                    <div className="text-foreground/60">ETA: {shipment.eta}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Stats */}
          <SupplyChainStats />
        </div>

        {/* Timeline & Map */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SupplyChainTimeline />
          <SupplyChainMap />
        </div>

        {/* Blockchain Verification */}
        <Card className="p-6 border-border/50 bg-primary/5">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-foreground mb-1">Blockchain Verified</h3>
              <p className="text-sm text-foreground/70 mb-3">
                All shipments are recorded on the Polkadot blockchain for complete transparency and immutability.
              </p>
              <Button variant="outline" className="bg-transparent border-primary/30 text-primary hover:bg-primary/10">
                View on Blockchain
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </main>
  )
}
