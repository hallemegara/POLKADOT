"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, TrendingUp } from "lucide-react"

export default function PaymentsPage() {
  const [selectedPayment, setSelectedPayment] = useState(null)

  const payments = [
    {
      id: 1,
      buyer: "Fresh Foods Ltd",
      product: "Cocoa Beans - Premium Grade",
      quantity: "500 kg",
      amount: 2500.0,
      date: "2024-10-15",
      status: "completed",
      daysToDeliver: 0,
    },
    {
      id: 2,
      buyer: "Global Coffee Traders",
      product: "Arabica Coffee Beans",
      quantity: "300 kg",
      amount: 1800.0,
      date: "2024-10-12",
      status: "completed",
      daysToDeliver: 0,
    },
    {
      id: 3,
      buyer: "Organic Produce Co",
      product: "Fresh Vegetables Mix",
      quantity: "200 kg",
      amount: 850.5,
      date: "2024-10-10",
      status: "pending",
      daysToDeliver: 2,
    },
    {
      id: 4,
      buyer: "Beauty & Wellness Inc",
      product: "Shea Butter - Raw",
      quantity: "100 kg",
      amount: 1200.0,
      date: "2024-10-08",
      status: "completed",
      daysToDeliver: 0,
    },
    {
      id: 5,
      buyer: "Nut Export Company",
      product: "Cashew Nuts - Grade A",
      quantity: "250 kg",
      amount: 1950.0,
      date: "2024-10-05",
      status: "completed",
      daysToDeliver: 0,
    },
  ]

  const stats = [
    {
      label: "Total Received",
      value: "$7350.00",
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-500/10",
    },
    {
      label: "Pending",
      value: "$850.50",
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-500/10",
    },
    {
      label: "This Month",
      value: "$3250.00",
      icon: TrendingUp,
      color: "text-blue-600",
      bgColor: "bg-blue-500/10",
    },
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
        return "bg-green-500/10 text-green-700 border-green-500/30"
      case "pending":
        return "bg-orange-500/10 text-orange-700 border-orange-500/30"
      case "failed":
        return "bg-red-500/10 text-red-700 border-red-500/30"
      default:
        return "bg-gray-500/10 text-gray-700 border-gray-500/30"
    }
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="section-padding container-max">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Payment History</h1>
          <p className="text-muted-foreground">Track all payments received from buyers on the Polkadot blockchain</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon
            return (
              <Card key={idx} className="p-6 card-hover">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Payments Table */}
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Buyer</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Product</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Quantity</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Amount</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Date</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {payments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-foreground">{payment.buyer}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{payment.product}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{payment.quantity}</td>
                    <td className="px-6 py-4 text-sm font-bold text-foreground">${payment.amount.toFixed(2)}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{payment.date}</td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className={getStatusColor(payment.status)}>
                        {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedPayment(payment)}
                        className="text-xs"
                      >
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Payment Details Modal */}
        {selectedPayment && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-md p-8 animate-scale-in">
              <h2 className="text-2xl font-bold mb-6">Payment Details</h2>
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Buyer:</span>
                  <span className="font-medium">{selectedPayment.buyer}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Product:</span>
                  <span className="font-medium">{selectedPayment.product}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount:</span>
                  <span className="font-bold text-lg text-primary">${selectedPayment.amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date:</span>
                  <span className="font-medium">{selectedPayment.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <Badge variant="outline" className={getStatusColor(selectedPayment.status)}>
                    {selectedPayment.status.charAt(0).toUpperCase() + selectedPayment.status.slice(1)}
                  </Badge>
                </div>
              </div>
              <Button className="w-full btn-primary" onClick={() => setSelectedPayment(null)}>
                Close
              </Button>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
