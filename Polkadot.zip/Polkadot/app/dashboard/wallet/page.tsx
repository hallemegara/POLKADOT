"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowUpRight, ArrowDownLeft, Send, Plus, Eye, EyeOff } from 'lucide-react'
import PolkadotConnection from "@/components/polkadot-connection"
import PolkadotAccount from "@/components/polkadot-account"

export default function WalletPage() {
  const [showBalance, setShowBalance] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  const walletBalance = 12450.75
  const polkadotAddress = "1A1z7agoat2Bq2BQo5sHSsi12345XYZ"
  const monthlyEarnings = 3250.0
  const pendingPayments = 850.5

  const transactions = [
    {
      id: 1,
      type: "received",
      description: "Payment from Buyer - Cocoa Batch #2024-001",
      amount: 2500.0,
      date: "2024-10-15",
      status: "completed",
    },
    {
      id: 2,
      type: "sent",
      description: "Withdrawal to Bank Account",
      amount: 1000.0,
      date: "2024-10-14",
      status: "completed",
    },
    {
      id: 3,
      type: "received",
      description: "Payment from Buyer - Coffee Batch #2024-003",
      amount: 1800.0,
      date: "2024-10-12",
      status: "completed",
    },
    {
      id: 4,
      type: "pending",
      description: "Pending Payment - Vegetables Batch #2024-005",
      amount: 850.5,
      date: "2024-10-10",
      status: "pending",
    },
    {
      id: 5,
      type: "received",
      description: "Payment from Buyer - Shea Butter Batch #2024-002",
      amount: 1200.0,
      date: "2024-10-08",
      status: "completed",
    },
  ]

  return (
    <div className="flex-1 overflow-auto">
      <div className="section-padding container-max">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Wallet & Payments</h1>
          <p className="text-muted-foreground">Manage your funds and track transactions on Polkadot blockchain</p>
        </div>

        <PolkadotConnection />

        {/* Wallet Balance Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="md:col-span-2 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20 p-8">
            <div className="flex justify-between items-start mb-8">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Total Balance</p>
                <div className="flex items-center gap-3">
                  <h2 className="text-4xl font-bold text-foreground">
                    {showBalance ? `$${walletBalance.toFixed(2)}` : "••••••"}
                  </h2>
                  <button
                    onClick={() => setShowBalance(!showBalance)}
                    className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
                  >
                    {showBalance ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <Badge className="bg-green-500/20 text-green-700 border-green-500/30">Active</Badge>
            </div>

            <div className="space-y-4 mb-8 pb-8 border-b border-primary/20">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Polkadot Address</span>
                <code className="text-xs bg-background/50 px-3 py-1 rounded font-mono text-foreground">
                  {polkadotAddress.slice(0, 10)}...{polkadotAddress.slice(-8)}
                </code>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Network</span>
                <Badge variant="outline" className="bg-primary/5">
                  Polkadot Mainnet
                </Badge>
              </div>
            </div>

            <div className="flex gap-3">
              <Button className="flex-1 btn-primary gap-2">
                <Plus className="w-4 h-4" />
                Add Funds
              </Button>
              <Button className="flex-1 btn-secondary gap-2">
                <Send className="w-4 h-4" />
                Send Payment
              </Button>
            </div>
          </Card>

          {/* Quick Stats */}
          <div className="space-y-4">
            <PolkadotAccount address={polkadotAddress} />
            <Card className="p-6 card-hover">
              <p className="text-sm text-muted-foreground mb-2">Monthly Earnings</p>
              <p className="text-2xl font-bold text-green-600">${monthlyEarnings.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-2">This month</p>
            </Card>
            <Card className="p-6 card-hover">
              <p className="text-sm text-muted-foreground mb-2">Pending Payments</p>
              <p className="text-2xl font-bold text-orange-600">${pendingPayments.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-2">Awaiting confirmation</p>
            </Card>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-border">
          {["overview", "transactions", "history"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium text-sm transition-colors ${
                activeTab === tab
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Transaction List */}
        <Card className="overflow-hidden">
          <div className="divide-y divide-border">
            {transactions.map((tx) => (
              <div key={tx.id} className="p-6 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div
                      className={`p-3 rounded-lg ${
                        tx.type === "received"
                          ? "bg-green-500/10"
                          : tx.type === "sent"
                            ? "bg-blue-500/10"
                            : "bg-orange-500/10"
                      }`}
                    >
                      {tx.type === "received" ? (
                        <ArrowDownLeft className="w-5 h-5 text-green-600" />
                      ) : tx.type === "sent" ? (
                        <ArrowUpRight className="w-5 h-5 text-blue-600" />
                      ) : (
                        <Send className="w-5 h-5 text-orange-600" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{tx.description}</p>
                      <p className="text-sm text-muted-foreground">{tx.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-bold text-lg ${
                        tx.type === "received"
                          ? "text-green-600"
                          : tx.type === "sent"
                            ? "text-blue-600"
                            : "text-orange-600"
                      }`}
                    >
                      {tx.type === "received" ? "+" : "-"}${tx.amount.toFixed(2)}
                    </p>
                    <Badge
                      variant="outline"
                      className={
                        tx.status === "completed"
                          ? "bg-green-500/10 text-green-700 border-green-500/30"
                          : "bg-orange-500/10 text-orange-700 border-orange-500/30"
                      }
                    >
                      {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
