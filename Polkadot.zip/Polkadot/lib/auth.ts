import crypto from "crypto"

// Simple in-memory user store (replace with database in production)
const users: Map<
  string,
  {
    id: string
    email: string
    password: string
    fullName: string
    farmName: string
    location: string
    cropType: string
  }
> = new Map()

// Hash password using crypto
export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

// Verify password
export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash
}

// Create user
export function createUser(
  email: string,
  password: string,
  fullName: string,
  farmName: string,
  location: string,
  cropType: string,
) {
  if (users.has(email)) {
    throw new Error("User already exists")
  }

  const user = {
    id: crypto.randomUUID(),
    email,
    password: hashPassword(password),
    fullName,
    farmName,
    location,
    cropType,
  }

  users.set(email, user)
  return { id: user.id, email: user.email, fullName: user.fullName }
}

// Find user by email
export function findUserByEmail(email: string) {
  return users.get(email)
}

// Get user by ID (without password)
export function getUserById(id: string) {
  for (const user of users.values()) {
    if (user.id === id) {
      const { password, ...userWithoutPassword } = user
      return userWithoutPassword
    }
  }
  return null
}
