export interface PolkadotAccount {
  address: string;
  name: string;
  balance: string;
  nonce: number;
}

export interface PolkadotTransaction {
  hash: string;
  blockNumber: number;
  from: string;
  to: string;
  amount: string;
  status: "pending" | "completed" | "failed";
  timestamp: number;
}

export interface PolkadotChainInfo {
  blockNumber: string;
  blockHash: string;
  chainName: string;
  chainVersion: string;
}

export interface PolkadotError {
  code: string;
  message: string;
}
