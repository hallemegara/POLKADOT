import { ApiPromise, WsProvider } from "@polkadot/api";
import type { PolkadotChainInfo, PolkadotAccount, PolkadotError } from "./types";

let apiInstance: ApiPromise | null = null;

export async function getPolkadotApi(): Promise<ApiPromise> {
  if (apiInstance) {
    return apiInstance;
  }

  try {
    const wsProvider = new WsProvider("wss://rpc.polkadot.io");
    apiInstance = await ApiPromise.create({ provider: wsProvider });
    return apiInstance;
  } catch (error) {
    throw {
      code: "POLKADOT_CONNECTION_ERROR",
      message: `Failed to connect to Polkadot: ${(error as any).message}`,
    } as PolkadotError;
  }
}

export async function getChainInfo(): Promise<PolkadotChainInfo> {
  try {
    const api = await getPolkadotApi();
    const [header, properties] = await Promise.all([
      api.rpc.chain.getHeader(),
      api.rpc.system.properties(),
    ]);

    return {
      blockNumber: header.number.toHuman() as string,
      blockHash: header.hash.toHex(),
      chainName: (properties.toJSON() as any)?.systemName || "Polkadot",
      chainVersion: (properties.toJSON() as any)?.systemVersion || "Unknown",
    };
  } catch (error) {
    throw {
      code: "CHAIN_INFO_ERROR",
      message: `Failed to fetch chain info: ${(error as any).message}`,
    } as PolkadotError;
  }
}

export async function getAccountBalance(address: string): Promise<string> {
  try {
    const api = await getPolkadotApi();
    const account = await api.query.system.account(address);
    const balance = account.data.free.toBigInt();
    
    // Convert from Planck to DOT (1 DOT = 10^10 Planck)
    return (Number(balance) / 1e10).toFixed(4);
  } catch (error) {
    throw {
      code: "BALANCE_ERROR",
      message: `Failed to fetch balance: ${(error as any).message}`,
    } as PolkadotError;
  }
}

export async function disconnect(): Promise<void> {
  if (apiInstance) {
    await apiInstance.disconnect();
    apiInstance = null;
  }
}
